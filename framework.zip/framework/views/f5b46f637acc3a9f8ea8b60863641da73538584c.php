

<?php $__env->startSection('content'); ?>

<!-- CONTENT -->
<div class="lg:pl-[320px] p-8 pb-48 pt-[108px] lg:pt-8 bg-black min-h-screen h-full text-white overflow-auto">
    <div id="trading">
        <section class="pt-16">
            <div class="flex justify-between items-center pl-4 mb-4 border-l-4 border-black border-white border-solid">
                <h1 class="font-bold text-primary">Thông tin cổ phiếu <span id="stockName" class="font-bold text-white"></span></h1>
                <input type="text" id="searchInput" placeholder="Nhập mã cổ phiếu..." class="border border-gray-300 rounded-md p-1 h-8 text-sm text-black" />
            </div>
            <p id="updateTime" class="pl-4 text-gray-600 mb-5"></p>

            <div class="w-full">
                <!-- TABLE -->
                <div class="list-box list-box-id max-w-full">
                    <?php if (count($data) > 0) { ?>
                        <?php
                        echo '<script>
                        const data = ' . json_encode($dataN) . ';
                        console.log("API getBuySell:", data);
                    </script>';
                        ?>
                        <div class="p-4 border border-[#3F3F3F] border-solid rounded-[26px] max-w-full overflow-auto">
                            <table class="table-fix js-table-1 font-light text-white text-xs w-full table-auto">
                                <thead>
                                    <tr class="font-light text-xs text-left text-white">
                                        <th class="min-w-[30px] border-table-left">
                                            <div class="py-3 px-1">Cổ phiếu</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Tín hiệu</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Giá khuyến nghị</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Giá hiện tại</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Ngày</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">T+</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Target1</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Target2</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Stoploss</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Tỷ trọng (%)</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Lãi tạm tính</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Thanh khoản 10 phiên</div>
                                        </th>
                                        <th class="min-w-[400px] border-table-middle">
                                            <div class="py-3 text-center pb-1 px-1 border-solid border-b border-b-neutral-700">Khuyến nghị hiện tại</div>
                                            <div class="flex pt-1 pb-3 text-[0.6rem]">
                                                <div class="px-1 w-[10%]">Xếp hạng cơ bản</div>
                                                <div class="px-1 w-[30%]">Loại cổ phiếu</div>
                                                <div class="px-1 w-[30%]">Tỷ trọng tối đa</div>
                                                <div class="px-1 w-[10%]">Sức mạnh giá (%)</div>
                                                <div class="px-1 w-[10%]">ROE (%)</div>
                                                <div class="px-1 w-[10%]">EPS</div>
                                            </div>
                                        </th>
                                        <th class="min-w-[26px] border-table-right"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $k = 0;
                                    $num = 0;
                                    $page = 1;
                                    $countData = count($data);
                                    foreach ($data as $key => $group) {
                                        $k++;
                                        $count = count($group);
                                        foreach ($group as $i => $item) {
                                            $num++; ?>
                                            <?php
                                            $class = 'text-red';
                                            if ((float)$item['provisionalInterest'] > 0) {
                                                $class = 'text-primary';
                                            } elseif ((float)$item['provisionalInterest'] == 0) {
                                                $class = 'text-yellow';
                                            } ?>
                                            <?php $eitem = $resultExcel[$key][0]; ?>
                                            <tr style="display: none;" data-num=<?php echo $num; ?> data-tytrongtoidanav="<?php echo $eitem[3]; ?>" data-xephang="<?php echo $eitem[1]; ?>" data-loai="<?php echo $eitem[2]; ?>" data-luandiem="<?php echo $eitem[7]; ?>" data-title="<?php echo e($key); ?>" data-signal="<?php echo e($item['signal']); ?>" data-giamua="<?php echo e($item['recommendedPrice']); ?>" data-ngaymua="<?php echo e(date('d/m/Y', strtotime($item['date']))); ?>" data-color="<?php echo e($class); ?>" data-lai="<?php echo e($item['provisionalInterest']); ?>" data-target1="<?php echo e($item['target1']); ?>" data-target2="<?php echo e($item['target2']); ?>" data-recommend="<?php echo e($item['recommendations']); ?>" class="table-fix-modal-btn hover:opacity-70 hover:cursor-pointer relative tr-page-<?php echo e($page); ?> tr-count-<?php echo e(($i===1) ? $count:''); ?> font-light text-xs text-center__ text-white">
                                                <?php if ($i === 0) { ?>
                                                    <td rowspan="<?php echo e($count); ?>" class="min-w-fit border-table-left">
                                                        <div class="py-3 px-1"><?php echo e($key); ?></div>
                                                    </td>
                                                <?php } ?>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['signal']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['recommendedPrice']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['currentPrice']); ?></div>
                                                </td>
                                                <td class="min-w-fit text-[0.6rem] border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e(date('d/m/Y H:i:s', strtotime($item['date']))); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['transactionTime']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-1 px-2">
                                                        <div class="p-1 rounded-lg bg-primary text-center">&nbsp;<?php echo e($item['target1']); ?>&nbsp;</div>
                                                    </div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-1 px-2">
                                                        <div class="p-1 rounded-lg bg-primary text-center">&nbsp;<?php echo e($item['target2']); ?>&nbsp;</div>
                                                    </div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['stoploss']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="px-4 py-2"><?php echo e($item['density']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1 <?php echo e($class); ?>"><?php echo e($item['provisionalInterest']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['liquidity']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 text-center pb-1 px-1 border-solid border-b border-b-neutral-700"><?php echo e($item['recommendations']); ?></div>
                                                    <?php if (isset($resultExcel[$key][0])) { ?>
                                                        <?php $eitem = $resultExcel[$key][0]; ?>
                                                        <div class="flex pt-1 pb-3 text-[0.6rem]">
                                                            <div class="px-1 w-[10%]"><?php echo e($eitem[1]); ?><?php if ($eitem[1] == "1 - RẤT ƯU TIÊN") echo '<span class="text-yellow-500 ml-1">★</span>'; ?></div>
                                                            <div class="px-1 w-[30%]"><?php echo e($eitem[2]); ?></div>
                                                            <div class="px-1 w-[30%]"><?php echo e($eitem[3]); ?></div>
                                                            <div class="px-1 w-[10%]"><?php echo e($eitem[4]); ?></div>
                                                            <div class="px-1 w-[10%]"><?php echo e(round($eitem[5],1)); ?></div>
                                                            <div class="px-1 w-[10%]"><?php echo e(round($eitem[6],1)); ?></div>
                                                        </div>
                                                    <?php } ?>
                                                </td>
                                                <?php if ($i === 0) { ?>
                                                    <td rowspan="<?php echo e($count); ?>" class="min-w-fit border-table-right"></td>
                                                <?php } ?>
                                            </tr>
                                    <?php }
                                        if ($k % 10 == 0 && $k < $countData) {
                                            $page++;
                                        }
                                    } ?>
                                </tbody>
                            </table>
                        </div>
                    <?php } else { ?>
                        Không tìm thấy dữ liệu
                    <?php } ?>
                </div>
            </div>
        </section>

        <section class="pt-16">
            <div class="flex justify-between items-center pl-4 mb-4 border-l-4 border-black border-white border-solid">
                <!-- <h1 class="font-bold text-primary">Emeralpha Ai Stock History</h1> -->
            </div>

            <div class="w-full">
                <!-- TABLE -->
                <div class="list-box list-box-id max-w-full">
                    <?php if (count($dataN) > 0) { ?>
                        <?php
                        echo '<script>
                        const data = ' . json_encode($dataN) . ';
                        console.log("API getBuySell:", data);
                    </script>';
                        ?>
                        <div class="p-4 border border-[#3F3F3F] border-solid rounded-[26px] max-w-full overflow-auto">
                            <table class="table-fix js-table-1 font-light text-white text-xs w-full table-auto">
                                <thead>
                                    <tr class="font-light text-xs text-left text-white">
                                        <th class="min-w-[30px] border-table-left">
                                            <div class="py-3 px-1">Cổ phiếu</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Tín hiệu</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Giá khuyến nghị</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Giá hiện tại</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Ngày</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">T+</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Target1</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Target2</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Stoploss</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Tỷ trọng (%)</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Lãi tạm tính</div>
                                        </th>
                                        <th class="min-w-[30px] border-table-middle">
                                            <div class="py-3 px-1">Thanh khoản 10 phiên</div>
                                        </th>
                                        <th class="min-w-[400px] border-table-middle">
                                            <div class="py-3 text-center pb-1 px-1 border-solid border-b border-b-neutral-700">Khuyến nghị hiện tại</div>
                                            <div class="flex pt-1 pb-3 text-[0.6rem]">
                                                <div class="px-1 w-[10%]">Xếp hạng cơ bản</div>
                                                <div class="px-1 w-[30%]">Loại cổ phiếu</div>
                                                <div class="px-1 w-[30%]">Tỷ trọng tối đa</div>
                                                <div class="px-1 w-[10%]">Sức mạnh giá (%)</div>
                                                <div class="px-1 w-[10%]">ROE (%)</div>
                                                <div class="px-1 w-[10%]">EPS</div>
                                            </div>
                                        </th>
                                        <th class="min-w-[26px] border-table-right"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $k = 0;
                                    $num = 0;
                                    $page = 1;
                                    $countData = count($dataN);
                                    foreach ($dataN as $key => $group) {
                                        $k++;
                                        $count = count($group);
                                        foreach ($group as $i => $item) {
                                            $num++; ?>
                                            <?php
                                            $class = 'text-red';
                                            if ((float)$item['provisionalInterest'] > 0) {
                                                $class = 'text-primary';
                                            } elseif ((float)$item['provisionalInterest'] == 0) {
                                                $class = 'text-yellow';
                                            } ?>
                                            <?php $eitem = $resultExcel[$key][0]; ?>
                                            <tr style="display: none;" data-num=<?php echo $num; ?> data-tytrongtoidanav="<?php echo $eitem[3]; ?>" data-xephang="<?php echo $eitem[1]; ?>" data-loai="<?php echo $eitem[2]; ?>" data-luandiem="<?php echo $eitem[7]; ?>" data-title="<?php echo e($key); ?>" data-signal="<?php echo e($item['signal']); ?>" data-giamua="<?php echo e($item['recommendedPrice']); ?>" data-ngaymua="<?php echo e(date('d/m/Y', strtotime($item['date']))); ?>" data-color="<?php echo e($class); ?>" data-lai="<?php echo e($item['provisionalInterest']); ?>" data-target1="<?php echo e($item['target1']); ?>" data-target2="<?php echo e($item['target2']); ?>" data-recommend="<?php echo e($item['recommendations']); ?>" class="table-fix-modal-btn hover:opacity-70 hover:cursor-pointer relative tr-page-<?php echo e($page); ?> tr-count-<?php echo e(($i===1) ? $count:''); ?> font-light text-xs text-center__ text-white">
                                                <?php if ($i === 0) { ?>
                                                    <td rowspan="<?php echo e($count); ?>" class="min-w-fit border-table-left">
                                                        <div class="py-3 px-1"><?php echo e($key); ?></div>
                                                    </td>
                                                <?php } ?>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['signal']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['recommendedPrice']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['currentPrice']); ?></div>
                                                </td>
                                                <td class="min-w-fit text-[0.6rem] border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e(date('d/m/Y H:i:s', strtotime($item['date']))); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['transactionTime']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-1 px-2">
                                                        <div class="p-1 rounded-lg bg-primary text-center">&nbsp;<?php echo e($item['target1']); ?>&nbsp;</div>
                                                    </div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-1 px-2">
                                                        <div class="p-1 rounded-lg bg-primary text-center">&nbsp;<?php echo e($item['target2']); ?>&nbsp;</div>
                                                    </div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['stoploss']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="px-4 py-2"><?php echo e($item['density']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1 <?php echo e($class); ?>"><?php echo e($item['provisionalInterest']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 px-1"><?php echo e($item['liquidity']); ?></div>
                                                </td>
                                                <td class="min-w-fit border-table-middle">
                                                    <div class="py-3 text-center pb-1 px-1 border-solid border-b border-b-neutral-700"><?php echo e($item['recommendations']); ?></div>
                                                    <?php if (isset($resultExcel[$key][0])) { ?>
                                                        <?php $eitem = $resultExcel[$key][0]; ?>
                                                        <div class="flex pt-1 pb-3 text-[0.6rem]">
                                                            <div class="px-1 w-[10%]"><?php echo e($eitem[1]); ?><?php if ($eitem[1] == "1 - RẤT ƯU TIÊN") echo '<span class="text-yellow-500 ml-1">★</span>'; ?></div>
                                                            <div class="px-1 w-[30%]"><?php echo e($eitem[2]); ?></div>
                                                            <div class="px-1 w-[30%]"><?php echo e($eitem[3]); ?></div>
                                                            <div class="px-1 w-[10%]"><?php echo e($eitem[4]); ?></div>
                                                            <div class="px-1 w-[10%]"><?php echo e(round($eitem[5],1)); ?></div>
                                                            <div class="px-1 w-[10%]"><?php echo e(round($eitem[6],1)); ?></div>
                                                        </div>
                                                    <?php } ?>
                                                </td>
                                                <?php if ($i === 0) { ?>
                                                    <td rowspan="<?php echo e($count); ?>" class="min-w-fit border-table-right"></td>
                                                <?php } ?>
                                            </tr>
                                    <?php }
                                        if ($k % 10 == 0 && $k < $countData) {
                                            $page++;
                                        }
                                    } ?>
                                </tbody>
                            </table>
                        </div>
                    <?php } else { ?>
                        Không tìm thấy dữ liệu
                    <?php } ?>
                </div>
            </div>
        </section>

        <?php if (isset($dash5)) {
            $item = $dash5;
        ?>
            <section class="pt-16">
                <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                    <h1 class="font-bold text-primary"><?php echo e($item['name']); ?></h1>
                </div>
                <?php if (isset($item['image'])) {
                    $pdf = $item['image'];
                    $pdf = explode('/', $pdf); ?>
                    <div>
                        <div class="m-auto border border-solid py-1 px-14 border-primary w-fit rounded-xl">
                            <a href="<?php echo e(Storage::url($item['image'])); ?>" target="_blank" alt="" class="w-full h-full object-contains flex items-center"><img class="mr-2" width="20px" src="<?php echo url('images/pdf.png'); ?>"> <?php echo e($item['name']); ?></a>
                        </div>
                    </div>
                <?php } ?>

            </section>
        <?php } ?>
    </div>
</div>

<div class="table-fix-modal">
    <div class="modal-body bg-black__ bg-white text-white__">
        <h4 class="text-2xl font-bold text-primary mb-2">EMERALPHA CAPITAL MANAGEMENT</h4>
        <h4 class="font-bold text-3xl leading-tight modal-title">Title</h4>
        <hr class="my-4 opacity-50__">
        <div class="flex gap-4 text-gray-600">
            <div class="w-1/2">
                <div class="text-xl__">Giá <span class="modal-signal lowercase"></span>: <span class="modal-giamua text-white__"></span></div>
                <div class="text-xl__">Ngày <span class="modal-signal lowercase"></span>: <span class="modal-ngaymua text-white__"></span></div>
                <div class="text-xl__">Lãi tạm tính: <span class="modal-lai text-white__"></span></div>
                <div class="text-xl__">Sức mạnh giá: <span class="modal-sucmanhgia text-white__"></span></div>
                <div class="text-xl__">ROE: <span class="modal-roe text-white__"></span></div>
                <div class="text-xl__">EPS: <span class="modal-eps text-white__"></span></div>
            </div>
            <div class="w-1/2">
                <div>Target 1: <span class="modal-target1 text-white__"></span></div>
                <div>Target2: <span class="modal-target2 text-white__"></span></div>
                <div>Tỷ trọng tối đa: <span class="modal-tytrongtoidanav text-white__"></span></div>
                <div>Thanh khoản trung bình 10 phiên: <span class="modal-thanhkhoan text-white__"></span></div>
                <div>Stop loss : <span class="modal-stoploss text-white__"></span></div>
            </div>
        </div>
        <hr class="my-4 opacity-50__">
        <div class="text-gray-600">Xếp hạng cơ bản: <span class="modal-xephang text-white__"></span></div>
        <div class="text-gray-600">Loại cổ phiếu: <span class="modal-loai text-gray-500 text-white__"></span></div>
        <div class="text-gray-600">Luận điểm đầu tư từ AI: <span class="block modal-luandiem text-white__ text-gray-500 italic"></span></div>
    </div>
</div>

<script>
    const searchInput = document.getElementById('searchInput');
    const stockName = document.getElementById('stockName');
    const updateTime = document.getElementById('updateTime');

    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const rows = document.querySelectorAll('.table-fix-modal-btn');

        let hasVisibleRows = false;
        let stockFound = '';
        const currentDateTime = new Date().toLocaleString(); 

        rows.forEach(row => {
            const title = row.getAttribute('data-title').toLowerCase();
            if (title.includes(searchTerm)) {
                row.style.display = '';
                hasVisibleRows = true;
                stockFound = title.toUpperCase();
            } else {
                row.style.display = 'none';
            }
        });

        if (searchTerm) {
            if (stockFound) {
                stockName.innerText = stockFound; 
                updateTime.innerText = `Cập nhật ${currentDateTime}`; 
            } else {
                stockName.innerText = ''; 
                updateTime.innerText = ''; 
            }
        } else {
            stockName.innerText = ''; 
            updateTime.innerText = ''; 
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home/lookup.blade.php ENDPATH**/ ?>
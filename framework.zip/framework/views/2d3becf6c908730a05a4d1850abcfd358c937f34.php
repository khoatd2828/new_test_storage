<?php $__env->startSection('content'); ?>

<!-- CONTENT -->
<div class="lg:pl-[320px] p-8 pb-48 pt-[108px] lg:pt-8 bg-black min-h-screen h-full text-white overflow-auto">
    <div id="reviews">
        <?php if ($evaluation) { ?>
            <section class="pt-0">
                <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                    <h1 class="font-bold text-primary"><?php echo $evaluation['name']; ?></h1>
                </div>
                <?php if ($evaluations) { ?>
                    <div class="flex flex-wrap flex-row justify-start">
                        <?php foreach ($evaluations as $i => $item) { ?>
                            <div class="w-full lg:w-1/2 px-2 pb-4">
                                <a href="<?php echo e(Storage::url($item['image'])); ?>" target="_blank" alt="" class="border border-solid p-4 border-primary w-full rounded-xl flex gap-3 items-center hover:bg-white/[.1]">
                                    <div class="min-w-[80px] max-w-[80px]">
                                        <img width="80px" src="<?php echo url('images/pdf.png'); ?>">
                                    </div>
                                    <div class="">
                                        <h5 class="text-lg text-primary">
                                            <span class="font-semibold"><?php echo $item['name']; ?></span>
                                        </h5>
                                        <div class="text-gray-300 text-sm"><?php echo nl2br(e($item['content'])); ?></div>
                                    </div>
                                </a>
                            </div>
                        <?php } ?>
                    </div>
                <?php } ?>
            </section>
        <?php } ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home/evaluation.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<!-- CONTENT -->
<div class="lg:pl-[320px] p-8 pb-48 pt-[108px] lg:pt-8 bg-black min-h-screen h-full text-white overflow-auto">
    <div id="consultation">
        <?php if (isset($dash7)) {
            $item = $dash7;
        ?>
            <section class="pt-0">
                <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                    <h1 class="font-bold text-primary"><?php echo e($item['name']); ?></h1>
                </div>
                <?php if (isset($item['image'])) { ?>
                    <div class="mb-8">
                        <div class="m-auto w-48">
                            <img src="<?php echo e(Storage::url($item['image'])); ?>" alt="chart" />
                        </div>
                    </div>
                <?php } ?>
                <?php if (isset($item['content'])) { ?>
                    <div class="text-center text-lg font-light">
                        <?php echo nl2br($item['content']); ?>
                    </div>
                <?php } ?>
            </section>
        <?php } ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home/consultation.blade.php ENDPATH**/ ?>
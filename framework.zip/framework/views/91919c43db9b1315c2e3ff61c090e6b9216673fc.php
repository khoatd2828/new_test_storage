<?php $__env->startSection('content'); ?>

<!-- CONTENT -->
<div class="lg:pl-[320px] p-8 pb-48 pt-[108px] lg:pt-8 bg-black min-h-screen h-full text-white overflow-auto">
    <div id="trend">
        <?php if($data2): ?>
        <section class="pt-0">
            <div class="pl-4 mb-4 border-l-4 border-black border-white border-solid">
                <h1 class="font-bold text-primary">Trạng thái thị trường</h1>
            </div>
            <div class="w-full">
                <div class="font-bold text-4xl w-[200px] leading-tight"><?php echo e($data2); ?></div>
            </div>
        </section>
        <?php endif; ?>
        <?php if($data2): ?>
        <?php
                        echo '<script>
                        const data = ' . json_encode($dataP) . ';
                        console.log("API getStockMarket:", data);
                    </script>';    
                        ?>
        <?php endif; ?>

        <?php if (isset($dash1)) {
            $item = $dash1;
        ?>
            <section class="pt-16">
                <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                    <h1 class="font-bold text-primary"><?php echo e($item['name']); ?></h1>
                </div>
                <?php if (isset($item['image'])) { ?>
                    <div class="mb-8">
                        <div class="m-auto max-w-lg border border-solid px-14 border-primary w-fit rounded-xl">
                            <img src="<?php echo e(Storage::url($item['image'])); ?>" alt="chart" />
                        </div>
                    </div>
                <?php } ?>
                <?php if (isset($item['content'])) { ?>
                    <div class="bg-gray-900 text-gray-400 p-4 text-sm">
                        <?php echo nl2br($item['content']); ?>
                    </div>
                <?php } ?>
            </section>
        <?php } ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home/trends.blade.php ENDPATH**/ ?>
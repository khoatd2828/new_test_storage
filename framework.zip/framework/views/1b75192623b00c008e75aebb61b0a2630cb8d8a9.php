<?php $__env->startSection('content'); ?>
<div class="lg:pl-[320px] p-8 pb-48 pt-[108px] lg:pt-8 bg-black min-h-screen h-full text-white overflow-auto">
    <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="text-sm">
        <div class="w-full pt-0">
            <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                <h1 class="font-bold text-primary">File Excel Đánh giá cơ bản cổ phiếu</h1>
            </div>
            <div class="w-full border border-solid rounded-[26px] border-[#343434] py-4">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('admin.tradingEdit')); ?>" class="lg:w-4/5 lg:px-2 px-4 w-full m-auto">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <input type="hidden" name="id" value="6" />
                    <input type="hidden" name="name" value="File Excel Đánh giá cơ bản cổ phiếu" />

                    <input type="file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" name="image" placeholder="PDF file upload" />
                    <div class="text-sm mb-4">Chỉ upload file .xlxs <a target="_blank" href="<?php echo url('images/get.xlsx'); ?>">theo mẫu</a></div>
                    <button type="submit" class="text-primary w-full block text-center px-2 py-4 rounded-lg border border-solid border-primary">
                        Add
                    </button>
                    <?php if (isset($dash6)) {
                        $pdf = $dash6['image'];
                        $pdf = explode('/', $pdf); ?>
                        <div class="mt-4">
                            <a href="<?php echo e(Storage::url($dash6['image'])); ?>" target="_blank" alt="" class="w-full h-full object-contains block"><?php echo end($pdf); ?></a>
                        </div>
                    <?php } ?>
                </form>
            </div>
        </div>
    </section>

    <section class="text-sm">
        <div class="w-full pt-16">
            <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                <?php $name = null; ?>
                <?php if (isset($dash5['name'])) {
                    $name = $dash5['name'];
                } ?>
                <h1 class="font-bold text-primary"><?php echo e(($name != null)? $name:'Emeralpha AI Đánh giá cơ bản cổ phiếu'); ?></h1>
                <!-- <h4 class="text-[#6B6B6B]">Market Image</h4> -->
            </div>
            <div class="w-full border border-solid rounded-[26px] border-[#343434] py-4">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('admin.tradingEdit')); ?>" class="lg:w-4/5 lg:px-2 px-4 w-full m-auto">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <input type="hidden" name="id" value="5" />

                    <input type="text" class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" name="name" placeholder="Title" value="<?php echo e(old('name', $name)); ?>" />

                    <input type="file" accept="application/pdf" class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" name="image" placeholder="PDF file upload" />
                    <div class="text-sm mb-4">Chỉ upload file .pdf</div>
                    <button type="submit" class="text-primary w-full block text-center px-2 py-4 rounded-lg border border-solid border-primary">
                        Add
                    </button>
                    <?php if (isset($dash5['image'])) {
                        $pdf = $dash5['image'];
                        $pdf = explode('/', $pdf); ?>
                        <div class="mt-4">
                            <a href="<?php echo e(Storage::url($dash5['image'])); ?>" target="_blank" alt="" class="w-full h-full object-contains block"><?php echo end($pdf); ?></a>
                        </div>
                    <?php } ?>
                </form>
            </div>
        </div>
    </section>

    <section class="text-sm">
        <div class="w-full pt-16">
            <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                <?php $name = null; ?>
                <?php if (isset($dash4['name'])) {
                    $name = $dash4['name'];
                } ?>
                <h1 class="font-bold text-primary"><?php echo e(($name != null)? $name:'Emeralpha AI Thống kê khuyến nghị'); ?></h1>
                <!-- <h4 class="text-[#6B6B6B]">Market Image</h4> -->
            </div>
            <div class="w-full border border-solid rounded-[26px] border-[#343434] py-4">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('admin.tradingEdit')); ?>" class="lg:w-4/5 lg:px-2 px-4 w-full m-auto">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <input type="hidden" name="id" value="4" />

                    <input type="text" class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" name="name" placeholder="Title" value="<?php echo e(old('name', $name)); ?>" />

                    <input type="file" multiple class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" name="images[]" />
                    <div class="text-sm mb-4">Chọn nhiều file hình khi upload. File mới sẽ ghi đè các file cũ.</div>

                    <button type="submit" class="text-primary w-full block text-center px-2 py-4 rounded-lg border border-solid border-primary">
                        Add
                    </button>
                    <?php if (isset($dash4['image'])) {
                        $images = json_decode($dash4['image']); ?>
                        <div class="mt-4 flex flex-wrap flex-row justify-start items-start">
                            <?php foreach ($images as $image) { ?>
                                <?php if (isset($image)) { ?>
                                    <div class="w-1/3 p-2">
                                        <img class="w-full h-full object-contains block" src="<?php echo e(Storage::url($image)); ?>" alt="chart" />
                                    </div>
                                <?php } ?>
                            <?php } ?>
                        </div>
                    <?php } ?>
                </form>
            </div>
        </div>
    </section>

    <section class="text-sm">
        <div class="w-full pt-16">
            <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                <h1 class="font-bold text-primary">Notice</h1>
            </div>
            <div class="w-full border border-solid rounded-[26px] border-[#343434] py-4">
                <form method="post" action="<?php echo e(route('admin.updateAnnouncement')); ?>" class="lg:w-4/5 lg:px-2 px-4 w-full m-auto">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label for="announcement" class="block text-sm mb-2">Nhập Thông Báo:</label>
                        <textarea id="announcement" name="announcement" class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858]" placeholder="Nhập thông báo"><?php echo e(old('announcement', $announcement ?? '')); ?></textarea>
                    </div>
                    <button type="submit" class="text-primary w-full block text-center px-2 py-4 rounded-lg border border-solid border-primary">
                        Lưu
                    </button>
                </form>
                <form method="post" action="<?php echo e(route('admin.deleteAnnouncement')); ?>" class="lg:w-4/5 lg:px-2 px-4 w-full m-auto mt-4">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-red-600 w-full block text-center px-2 py-4 rounded-lg border border-solid border-red-600">
                        Xóa Thông Báo
                    </button>
                </form>
            </div>
        </div>
    </section>

    <script>
        // Kiểm tra biến PHP trong JavaScript
        var announcement = <?php echo json_encode($announcement); ?>; // Chuyển đổi biến PHP sang JavaScript
        console.log("Giá trị của announcement:", announcement); // In ra console
    </script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/trading.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(route('login.perform')); ?>" id="login-form" class="absolute max-xl:m-auto top-[10%] right-[20%] max-xl:p-6 max-xl:static max-xl:top-0 max-xl:left-0 max-xl:rounded-none text-white w-full px-[30px] py-[27px] max-w-[479px] bg-gradient-custom rounded-[27px]">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

    <h4 class="text-xl font-bold">Login</h4>
    <div class="w-[10%] min-w-[110px] max-w-[110px] border-b-white border-b border-solid pt-4"></div>
    <div class="pt-[8px] pb-[14px]">Welcome onboard with us!</div>

    <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex flex-col pb-4">
        <label for="user-name" class="pb-2 text-sm font-medium">Username</label>
        <input class="p-4 text-sm text-white border-solid rounded-md font-extralight placeholder:text-[rgba(255,255,255,0.6)] bg-gradient-custom" type="text" placeholder="Enter your username" value="<?php echo e(old('username')); ?>" name="username" required="required" />
    </div>
    <?php if($errors->has('username')): ?>
    <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
    <?php endif; ?>  
    <div class="flex flex-col">
        <label for="user-name" class="pb-2 text-sm font-medium">Password</label>
        <input class="p-4 text-sm text-white border-solid rounded-md font-extralight placeholder:text-[rgba(255,255,255,0.6)] bg-gradient-custom" type="password" placeholder="Enter your password" value="<?php echo e(old('password')); ?>" name="password" required="required" />
    </div>
    <?php if($errors->has('password')): ?>
    <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
    <?php endif; ?>

    <button class="block w-full p-6 text-center text-white uppercase max-xl:mt-8 max-xl:p-4 mt-36 bg-primary-light" type="submit">
        Login
    </button>
</form>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/login.blade.php ENDPATH**/ ?>
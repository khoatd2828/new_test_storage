<header class="fixed lg:hidden bg-black flex justify-between w-full align-center z-50">
  <div class="p-2 px-8 text-sm text-primary">
    <div class="flex gap-2 flex-row align-center items-center">
      <img class="w-14 lg:w-16" src="<?php echo url('images/logo.png'); ?>">
      <div>
        <h1>Emeralpha Capital</h1>
        <h1>Management</h1>
      </div>
    </div>
  </div>
  <button id="nav-hamburger" type="button" class="ml-6 w-20 h-20 p-2 text-sm text-gray-500 rounded-lg">
    <svg class="w-10 h-10" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
      <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15" />
    </svg>
  </button>
</header>
<nav id="navbar" class="w-[300px] h-full block fixed left-0 top-0 z-20 bg-black border-r border-solid border-[#9E9E9E] z-50">
  <div class="navbar-scroll mx-auto overflow-auto h-full">
    <div id="nav-menu" class="w-full">
      <div class="p-8 px-4 text-lg text-primary">
        <div class="flex gap-2 flex-row align-center items-center">
          <img class="w-16" src="<?php echo url('images/logo.png'); ?>">
          <div>
            <h1>Emeralpha Capital</h1>
            <h1>Management</h1>
          </div>
        </div>
      </div>
      <div class="p-4 px-4 flex flex-row align-center text-[#9E9E9E]" id="avarta">
        <div>
          <div class="mb-2">Hello 👋</div>
          <div class="text-lg text-white"><?php echo e(auth()->user()->username); ?></div>
        </div>
      </div>

      <ul class="flex p-4 py-2 flex-col font-medium text-[#9E9E9E]">
        <li>
          <a href="javascript:;" class="flex flex-row p-3 py-2 items-center align-center hover:bg-primary-light <?php if(in_array(Request::url(), [url('/'), url('/ai-trading'), url('/ai-trading-history'), url('/user-manual'), url('/stock-evaluation'), url('/private-consultation'), url('/strategic-hexagram'), url('/ai-copytrade'), url('/psychology-power'), url('/market-trends')])): ?> <?php echo e('bg-primary'); ?> <?php endif; ?>" aria-controls="dropdown-dashboard" data-collapse-toggle="dropdown-dashboard">
            <img class="w-[22px] height-[22px]" src="<?php echo url('images/menu-dashboard.svg'); ?>" alt="" />
            <span class="block w-full px-3 py-2 rounded md:bg-transparent">Dashboard</span>
            <svg class="w-3 h-3" aria-hidden="<?php if(in_array(Request::url(), [url('/'), url('/ai-trading')])): ?> <?php echo e('true'); ?> <?php else: ?> <?php echo e('false'); ?> <?php endif; ?>" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4" />
            </svg>
          </a>
          <ul id="dropdown-dashboard" class="list-disc pl-11 <?php if(in_array(Request::url(), [url('/'), url('/ai-trading'), url('/ai-trading-history'), url('/user-manual'), url('/stock-evaluation'), url('/private-consultation'), url('/strategic-hexagram'), url('/ai-copytrade'), url('/psychology-power'), url('/market-trends')])): ?> <?php echo e('hidden__'); ?> <?php else: ?> <?php echo e('hidden'); ?> <?php endif; ?> py-2 space-y-2">
            <li>
              <a href="<?php echo e(url('/ai-trading')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/ai-trading') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">EMERALPHA AI TRADING SYSTEM</a>
            </li>
            <li>
              <a href="<?php echo e(url('/ai-trading-history')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/ai-trading-history') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">HISTORY EMERALPHA AI</a>
            </li>
            <li>
              <a href="<?php echo e(url('/market-trends')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/market-trends') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Xu hướng thị trường & <br> Tỷ trọng danh mục</a>
            </li>
            <li>
              <a href="<?php echo e(url('/psychology-power')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/psychology-power') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Sức mạnh thị trường & Tâm lý thị trường</a>
            </li>
            <li>
              <a href="<?php echo e(url('/strategic-hexagram')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/strategic-hexagram') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">EMERALPHA AI Gieo quẻ chiến lược</a>
            </li>
            <li>
              <a href="<?php echo e(url('/ai-copytrade')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/ai-copytrade') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">EMERALPHA AI COPYTRADE</a>
            </li>
            <li>
              <a href="<?php echo e(url('/private-consultation')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/private-consultation') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Nâng cấp Tư vấn riêng 1:1 cùng chuyên gia</a>
            </li>
            <li>
              <a href="<?php echo e(url('/stock-lockup')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/stock-lockup') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Tra cứu cổ phiếu</a>
            </li>
            <li>
              <a href="<?php echo e(url('/stock-evaluation')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/stock-evaluation') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">EMERALPHA AI Đánh giá chuyên sâu cổ phiếu</a>
            </li>
            <li>
              <a href="<?php echo e(url('/user-manual')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/user-manual') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Hướng dẫn sử dụng</a>
            </li>
          </ul>
        </li>
        <li class="flex flex-row p-4 py-2 align-center hover:bg-primary-light <?php if(url('/about') === Request::url()): ?> <?php echo e('bg-primary'); ?> <?php endif; ?>">
          <img class="w-[22px] height-[22px]" src="<?php echo url('images/menu-intro.svg'); ?>" alt="dashboard" />
          <a href="<?php echo e(url('/about')); ?>" class="block w-full px-3 py-2 rounded md:bg-transparent" aria-current="page">Giới thiệu</a>
        </li>
        <?php if(auth()->user()->group_id === 1): ?>
        <li class="p-4">
          <hr class="opacity-50">
        </li>
        <li>
          <a href="javascript:;" class="flex flex-row p-3 py-2 items-center align-center hover:bg-primary-light <?php if(in_array(Request::url(), [url('/admin'), url('/admin/ai-trading'), url('/admin/user-manual'), url('/admin/stock-evaluation'), url('/admin/private-consultation'), url('/admin/strategic-hexagram'), url('/admin/psychology-power'), url('/admin/market-trends')])): ?> <?php echo e('bg-primary'); ?> <?php endif; ?>" aria-controls="dropdown-dashboard-admin" data-collapse-toggle="dropdown-dashboard-admin">
            <img class="w-[22px] height-[22px]" src="<?php echo url('images/menu-pen.svg'); ?>" alt="" />
            <span class="block w-full px-3 py-2 rounded md:bg-transparent">Quản lý Dashboard</span>
            <svg class="w-3 h-3" aria-hidden="<?php if(in_array(Request::url(), [url('/admin/'), url('/admin/ai-trading')])): ?> <?php echo e('true'); ?> <?php else: ?> <?php echo e('false'); ?> <?php endif; ?>" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4" />
            </svg>
          </a>
          <ul id="dropdown-dashboard-admin" class="list-disc pl-11 <?php if(in_array(Request::url(), [url('/admin/'), url('/admin/ai-trading'), url('/admin/user-manual'), url('/admin/stock-evaluation'), url('/admin/private-consultation'), url('/admin/strategic-hexagram'), url('/admin/psychology-power'), url('/admin/market-trends')])): ?> <?php echo e('hidden__'); ?> <?php else: ?> <?php echo e('hidden'); ?> <?php endif; ?> py-2 space-y-2">
            <li>
              <a href="<?php echo e(url('/admin/ai-trading')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/admin/ai-trading') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">EMERALPHA AI TRADING SYSTEM</a>
            </li>
            <li>
              <a href="<?php echo e(url('/admin/market-trends')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/admin/market-trends') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Xu hướng thị trường & <br> Tỷ trọng danh mục</a>
            </li>
            <li>
              <a href="<?php echo e(url('/admin/psychology-power')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/admin/psychology-power') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Sức mạnh thị trường & Tâm lý thị trường</a>
            </li>
            <li>
              <a href="<?php echo e(url('/admin/strategic-hexagram')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/admin/strategic-hexagram') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">EMERALPHA AI Gieo quẻ chiến lược</a>
            </li>
            <li>
              <a href="<?php echo e(url('/admin/ai-copytrade')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/admin/ai-copytrade') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">EMERALPHA AI COPYTRADE</a>
            </li>
            <li>
              <a href="<?php echo e(url('/admin/private-consultation')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/admin/private-consultation') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Nâng cấp Tư vấn riêng 1:1 cùng chuyên gia</a>
            </li>
            <li>
              <a href="<?php echo e(url('/admin/stock-evaluation')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/admin/stock-evaluation') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">EMERALPHA AI Đánh giá chuyên sâu cổ phiếu</a>
            </li>
            <li>
              <a href="<?php echo e(url('/admin/user-manual')); ?>" class="flex items-center w-full p-2 text-[#9E9E9E] transition duration-75 rounded-lg pl-0 group hover:text-primary <?php if(url('/admin/user-manual') === Request::url()): ?> <?php echo e('text-primary'); ?> <?php endif; ?>">Hướng dẫn sử dụng</a>
            </li>
          </ul>
        </li>

        <li class="flex flex-row p-4 py-2 align-center hover:bg-primary-light <?php if(str_contains(Request::url(), url('/edit-account'))): ?> <?php echo e('bg-primary'); ?> <?php endif; ?>">
          <img class="w-[22px] height-[22px]" src="<?php echo url('images/menu-pen.svg'); ?>" alt="dashboard" />
          <a href="<?php echo e(url('/edit-account')); ?>" class="block w-full px-3 py-2 rounded md:bg-transparent" aria-current="page">Quản lý tài khoản</a>
        </li>
        <li class="flex flex-row p-4 py-2 align-center hover:bg-primary-light <?php if(url('/edit-about') === Request::url()): ?> <?php echo e('bg-primary'); ?> <?php endif; ?>">
          <img class="w-[22px] height-[22px]" src="<?php echo url('images/menu-pen.svg'); ?>" alt="dashboard" />
          <a href="<?php echo e(url('/edit-about')); ?>" class="block w-full px-3 py-2 rounded md:bg-transparent" aria-current="page">Quản lý giới thiệu</a>
        </li>
        <li class="flex flex-row p-4 py-2 align-center hover:bg-primary-light <?php if(url('/edit-setting') === Request::url()): ?> <?php echo e('bg-primary'); ?> <?php endif; ?>">
          <img class="w-[22px] height-[22px]" src="<?php echo url('images/menu-pen.svg'); ?>" alt="dashboard" />
          <a href="<?php echo e(url('/edit-setting')); ?>" class="block w-full px-3 py-2 rounded md:bg-transparent" aria-current="page">Tùy chỉnh trang</a>
        </li>
        <?php endif; ?>
        <li class="flex flex-row p-4 py-2 align-center hover:bg-primary-light">
          <img class="w-[22px] height-[22px]" src="<?php echo url('images/menu-logout.svg'); ?>" alt="dashboard" />
          <a href="<?php echo e(route('logout.perform')); ?>" class="block w-full px-3 py-2 rounded md:bg-transparent" aria-current="page">Thoát</a>
        </li>

      </ul>

    </div>
  </div>
</nav><?php /**PATH /var/www/html/resources/views/layouts/partials/navbar.blade.php ENDPATH**/ ?>
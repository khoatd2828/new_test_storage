

<?php $__env->startSection('content'); ?>
<div class="lg:pl-[320px] p-8 pb-48 pt-[108px] lg:pt-8 bg-black min-h-screen h-full text-white overflow-auto">
    <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="text-sm grid grid-cols-1 lg:grid-cols-1 gap-4">
        <?php
        $name = '';
        $content = '';
        if ($copytrade) {
            $name = $copytrade['name'];
            $content = $copytrade['content'];
        } ?>
        <?php echo '<script>
                        var data = ' . json_encode($copytrades) . ';
                        console.log(JSON.stringify(data, null, 2));
                    </script>'; ?>
        <div class="w-full mb-16">
            <div class="pl-4 mb-8 border-l-4 border-black border-white border-solid">
                <h1 class="font-bold text-primary">EMERALPHA AI Copytrade</h1>
                <!-- <h4 class="text-[#6B6B6B]">Market Image</h4> -->
            </div>
            <div class="w-full border border-solid rounded-[26px] border-[#343434] py-4">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('admin.copytradeEdit')); ?>" class="lg:w-4/5 lg:px-2 px-4 w-full m-auto">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

                    <input type="text" class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" name="name1" placeholder="Title" value="<?php echo e(old('name1', $name)); ?>" />
                    <textarea class="hidden w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Content" name="content1"><?php echo e(old('content1', $content)); ?></textarea>
                    <button name="submit3" type="submit" class="text-primary w-full block text-center px-2 py-4 rounded-lg border border-solid border-primary">
                        Save
                    </button>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <?php if ($copytrade) { ?>
                        <div class="pt-5 max-w-full">
                            <div class="p-4 border border-[#3F3F3F] border-solid rounded-[26px] lg:max-w-full max-w-fit overflow-auto">
                                <table class="table-fix table-fix2 font-light text-white font-sm w-fit lg:w-full table-auto">
                                    <tbody>
                                        <?php if ($copytrades) { ?>
                                            <?php foreach ($copytrades as $i => $item) { ?>
                                                <tr class="font-light text-sm text-white tr-page-1">
                                                    <td class="min-w-fit border-table-middle min-w-[200px]">
                                                        <div class="py-4 px-2"><?php echo nl2br(e($item['name'])); ?></div>
                                                    </td>
                                                    <td class="min-w-fit border-table-middle">
                                                        <div class="py-4 px-2"><?php echo nl2br($item['content']); ?></div>
                                                    </td>
                                                    <td class="min-w-fit relative border-table-right">
                                                        <div class="py-4 px-2 table-icons-col justify-start">
                                                            <?php if( $item['id'] != auth()->user()->id ): ?>
                                                            <a href="<?php echo e(url('/deleteAboutCopytrade/' . $item['id'] )); ?>" onclick="return confirm('Are you sure?')" class="block p-2 bg-[#2B2B2B] rounded-md w-[32px] h-[32px]">
                                                                <img class="block" src="<?php echo url('images/delete.svg'); ?>" alt="delete" />
                                                            </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        <?php } ?>

                                        <tr class="font-light text-sm text-white tr-page-1">
                                            <td class="border-table-middle min-w-[200px]">
                                                <div class="py-4 px-2">
                                                    <textarea class="w-full p-2 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Name" name="namenew1"><?php echo e(old('namenew1')); ?></textarea>
                                                </div>
                                            </td>
                                            <td class="min-w-fit border-table-middle">
                                                <div class="py-4 px-2">
                                                    <textarea class="w-full p-2 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Content" name="contentnew1"><?php echo e(old('contentnew1')); ?></textarea>
                                                </div>
                                            </td>
                                            <td class="min-w-fit relative border-table-right">
                                                <div class="py-4 px-2">
                                                    <button name="submit3a" type="submit" class="text-primary block text-center px-4 py-2 rounded-lg border border-solid border-primary">
                                                        Save
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php } ?>
                </form>
            </div>
        </div>
    </section>

    <section class="text-sm grid grid-cols-1 lg:grid-cols-1 gap-4">
        <?php
        $nameN = '';
        $contentN = '';
        if ($copytradeN) {
            $nameN = $copytradeN['name'];
            $contentN = $copytradeN['content'];
        } ?>
        <?php echo '<script>
                        var data = ' . json_encode($copytradesN) . ';
                       console.log(JSON.stringify(data, null, 2));
                    </script>'; ?>
        <div class="w-full mb-16">

            <div class="w-full border border-solid rounded-[26px] border-[#343434] py-4">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('admin.copytradeEdit')); ?>" class="lg:w-4/5 lg:px-2 px-4 w-full m-auto">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

                    <input type="text" class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" name="name1" placeholder="Title" value="<?php echo e(old('name1', $name)); ?>" />
                    <textarea class="hidden w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Content" name="content1"><?php echo e(old('content1', $content)); ?></textarea>
                    <button name="submit3N" type="submit" class="text-primary w-full block text-center px-2 py-4 rounded-lg border border-solid border-primary">
                        Save
                    </button>
                    <?php if ($copytradeN) { ?>
                        <div class="pt-5 max-w-full">
                            <div class="p-4 border border-[#3F3F3F] border-solid rounded-[26px] lg:max-w-full max-w-fit overflow-auto">
                                <table class="table-fix table-fix2 font-light text-white font-sm w-fit lg:w-full table-auto">
                                    <tbody>
                                        <?php if ($copytradesN) { ?>
                                            <?php foreach ($copytradesN as $i => $item) { ?>
                                                <tr class="font-light text-sm text-white tr-page-1">
                                                    <td class="min-w-fit border-table-middle min-w-[200px]">
                                                        <div class="py-4 px-2"><?php echo nl2br(e($item['name'])); ?></div>
                                                    </td>
                                                    <td class="min-w-fit border-table-middle">
                                                        <div class="py-4 px-2"><?php echo nl2br($item['content']); ?></div>
                                                    </td>
                                                    <td class="min-w-fit relative border-table-right">
                                                        <div class="py-4 px-2 table-icons-col justify-start">
                                                            <?php if( $item['id'] != auth()->user()->id ): ?>
                                                            <a href="<?php echo e(url('/deleteAboutCopytrade/' . $item['id'] )); ?>" onclick="return confirm('Are you sure?')" class="block p-2 bg-[#2B2B2B] rounded-md w-[32px] h-[32px]">
                                                                <img class="block" src="<?php echo url('images/delete.svg'); ?>" alt="delete" />
                                                            </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        <?php } ?>

                                        <tr class="font-light text-sm text-white tr-page-1">
                                            <td class="border-table-middle min-w-[200px]">
                                                <div class="py-4 px-2">
                                                    <textarea class="w-full p-2 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Name" name="namenew1N"><?php echo e(old('namenew1N')); ?></textarea>
                                                </div>
                                            </td>
                                            <td class="min-w-fit border-table-middle">
                                                <div class="py-4 px-2">
                                                    <textarea class="w-full p-2 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Content" name="contentnew1N"><?php echo e(old('contentnew1N')); ?></textarea>
                                                </div>
                                            </td>
                                            <td class="min-w-fit relative border-table-right">
                                                <div class="py-4 px-2">
                                                    <button name="submit3aN" type="submit" class="text-primary block text-center px-4 py-2 rounded-lg border border-solid border-primary">
                                                        Save
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php } ?>
                </form>
            </div>
        </div>
    </section>

    <section class="text-sm grid grid-cols-1 lg:grid-cols-1 gap-4">
        <?php
        $nameP = '';
        $content = '';
        if ($copytradeP) {
            $nameP = $copytradeP['name'];
            $contentP = $copytradeP['content'];
        } ?>
        <?php echo '<script>
                        var data = ' . json_encode($copytradesP) . ';
                        console.log(JSON.stringify(data, null, 2));
                    </script>'; ?>
        <div class="w-full mb-16">
            <div class="w-full border border-solid rounded-[26px] border-[#343434] py-4">
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('admin.copytradeEdit')); ?>" class="lg:w-4/5 lg:px-2 px-4 w-full m-auto">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

                    <input type="text" class="w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" name="name1" placeholder="Title" value="<?php echo e(old('name1', $name)); ?>" />
                    <textarea class="hidden w-full p-4 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Content" name="content1"><?php echo e(old('content1', $content)); ?></textarea>
                    <button name="submit3P" type="submit" class="text-primary w-full block text-center px-2 py-4 rounded-lg border border-solid border-primary">
                        Save
                    </button>
                    <?php if ($copytradeP) { ?>
                        <div class="pt-5 max-w-full">
                            <div class="p-4 border border-[#3F3F3F] border-solid rounded-[26px] lg:max-w-full max-w-fit overflow-auto">
                                <table class="table-fix table-fix2 font-light text-white font-sm w-fit lg:w-full table-auto">
                                    <tbody>
                                        <?php if ($copytradesP) { ?>
                                            <?php foreach ($copytradesP as $i => $item) { ?>
                                                <tr class="font-light text-sm text-white tr-page-1">
                                                    <td class="min-w-fit border-table-middle min-w-[200px]">
                                                        <div class="py-4 px-2"><?php echo nl2br(e($item['name'])); ?></div>
                                                    </td>
                                                    <td class="min-w-fit border-table-middle">
                                                        <div class="py-4 px-2"><?php echo nl2br($item['content']); ?></div>
                                                    </td>
                                                    <td class="min-w-fit relative border-table-right">
                                                        <div class="py-4 px-2 table-icons-col justify-start">
                                                            <?php if( $item['id'] != auth()->user()->id ): ?>
                                                            <a href="<?php echo e(url('/deleteAboutCopytrade/' . $item['id'] )); ?>" onclick="return confirm('Are you sure?')" class="block p-2 bg-[#2B2B2B] rounded-md w-[32px] h-[32px]">
                                                                <img class="block" src="<?php echo url('images/delete.svg'); ?>" alt="delete" />
                                                            </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        <?php } ?>

                                        <tr class="font-light text-sm text-white tr-page-1">
                                            <td class="border-table-middle min-w-[200px]">
                                                <div class="py-4 px-2">
                                                    <textarea class="w-full p-2 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Name" name="namenew1P"><?php echo e(old('namenew1P')); ?></textarea>
                                                </div>
                                            </td>
                                            <td class="min-w-fit border-table-middle">
                                                <div class="py-4 px-2">
                                                    <textarea class="w-full p-2 bg-[#2B2B2B] rounded-md text-[#fff] text-sm placeholder-[#585858] mb-4" rows="5" placeholder="Content" name="contentnew1P"><?php echo e(old('contentnew1P')); ?></textarea>
                                                </div>
                                            </td>
                                            <td class="min-w-fit relative border-table-right">
                                                <div class="py-4 px-2">
                                                    <button name="submit3aP" type="submit" class="text-primary block text-center px-4 py-2 rounded-lg border border-solid border-primary">
                                                        Save
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php } ?>
                </form>
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/copytrade.blade.php ENDPATH**/ ?>
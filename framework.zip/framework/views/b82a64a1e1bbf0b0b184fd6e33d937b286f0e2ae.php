<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Emeralpha Capital Management</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="<?php echo url('styles/base.css'); ?>" />
  <link rel="stylesheet" href="<?php echo url('styles/custom.css'); ?>" />
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: "#0A822C",
            ["primary-light"]: "rgba(30, 203, 79, 0.55)",
            white: "#fff",
          },
        },
      },
    };
  </script>
  <style>
    .arrow-right {
      clip-path: polygon(0 0, 100% 50%, 0 100%);
    }
  </style>
</head>

<body>
  <div class="relative w-screen h-screen min-h-screen min-w-screen">
    <img src="<?php echo url('images/login-bg.png'); ?>" class="object-cover w-full h-full" />
    <div class="absolute top-0 left-0 flex flex-row items-center w-full h-full max-xl: max-xl:flex-col">
      <div class="w-1/2 max-xl:text-center p-11 max-xl:p-4 max-xl:mb-4 max-xl:w-full">
        <h1 class="pb-6 text-5xl font-bold max-xl:text-2xl max-xl:pb-2 text-primary">
          Emeralpha Capital<br>
          <!-- </h1>
        <h1 class="pb-4 text-5xl font-light max-xl:text-2xl max-xl:pb-2 text-primary"> -->
          Management
        </h1>
        <div class="pb-6 text-lg font-light text-white">
          Please fill the form on the right side.
        </div>
        <hr class="pb-4 opacity-50">
        <?php $options = $settings['options']; ?>
        <?php if (isset($options['website'])) { ?>
          <div class="text-lg font-light">
            <span class="text-white opacity-75">Website:</span>
            <a href="http://<?php echo $options['website']['url']; ?>" class="text-white hover:text-primary" target="_blank"><?php echo $options['website']['url']; ?></a>
          </div>
        <?php } ?>
        <?php if (isset($options['email'])) { ?>
          <div class="text-lg font-light">
            <span class="text-white opacity-75">Email:</span>
            <a href="mailto:<?php echo $options['email']['url']; ?>" class="text-white hover:text-primary" target="_blank"><?php echo $options['email']['url']; ?></a>
          </div>
        <?php } ?>
        <div class="text-lg font-light">
          <span class="text-white opacity-75">Phone:</span>
          <?php if (isset($options['phone1']) && $options['phone1']['url'] != '') { ?>
            <a class="text-white hover:text-primary" href="tel:<?php echo $options['phone1']['url']; ?>" target="_blank"><?php echo $options['phone1']['url']; ?></a>
          <?php } ?>
          <?php if (isset($options['phone2']) && $options['phone2']['url'] != '') { ?>
            <span class="text-white"> - </span>
            <a class="text-white hover:text-primary" href="tel:<?php echo $options['phone2']['url']; ?>" target="_blank"><?php echo $options['phone2']['url']; ?></a>
          <?php } ?>
        </div>
      </div>

      <div class="relative w-1/2 h-full max-xl:w-full">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </div>

    <div class="bg-white md:p-10 p-3 w-full text-center">
      <h1 class="text-2xl font-bold mb-5 text-green-600">Trải nghiệm phiên bản PRO</h1>

      <div class="flex justify-center gap-20 mb-8">
        <a href="" target="" rel="" class=""><img class="w-[150px] h-[50px]" src="images/appstore.png" alt="app"></a>
        <a href="" target="" rel="" class=""><img class="w-[170px] h-[75px] mt-[-13px]" src="images/ggplay.png" alt="app"></a>
      </div>

      <div class="bg-white rounded-2xl p-10 shadow-lg w-full h-[800px] md:h-[580px] lg:h-[650px] mx-auto text-center mt-10 border border-gray-200 relative" style="background-image: url('images/ck_banner.jpg'); background-size: cover; background-position: center;">
        <h1 class="text-3xl font-bold text-green-700 relative z-10" style="text-shadow: 0px 0px 10px rgba(255, 255, 255, 0.8), 0px 0px 20px rgba(255, 255, 255, 0.6); -webkit-text-stroke: 1px white;">
          Emeralpha AI
        </h1>

        <div class="mt-5 bg-white bg-opacity-10 rounded-lg p-6 shadow-lg flex justify-center mb-5  ">
          <img src="images/logo.png" alt="Logo" class="md:w-48 w-24">
        </div>

        <div class="grid md:grid-cols-3 grid-cols-1 gap-6 lg:gap-12 relative z-10">
          <div class="relative bg-white rounded-lg p-0 lg:p-4 shadow-md hover:bg-green-700 hover:scale-105 transform transition duration-300 shadow-green-500">
            <img src="images/thuc-chien.png" alt="Thực chiến Logo" class="w-24 mx-auto lg:mt-[4px]">
            <h2 class="text-2xl uppercase mt-[6px]">Thực chiến</h2>
            <div class="absolute inset-0 bg-white opacity-10 rounded-lg pointer-events-none"></div>
          </div>

          <div class="relative bg-white rounded-lg p-0 lg:p-4 shadow-md hover:bg-green-700 hover:scale-105 transform transition duration-300 shadow-green-500">
            <img src="images/deep.png" alt="Chuyên sâu Logo" class="w-16 mx-auto mb-0 lg:mb-3 mt-[20px] lg:mt-[18px]">
            <h2 class="text-2xl uppercase mt-3 lg:mt-[28px]">Chuyên sâu</h2>
            <div class="absolute inset-0 bg-white opacity-10 rounded-lg pointer-events-none"></div>
          </div>

          <div class="relative bg-white rounded-lg p-0 lg:p-4 shadow-md hover:bg-green-700 hover:scale-105 transform transition duration-300 shadow-green-500">
            <img src="images/hieuqua.png" alt="Hiệu quả Logo" class="lg:w-24 w-[70px] mt-4 lg:mt-0 mx-auto mb-3">
            <h2 class="text-2xl uppercase mt-2">Hiệu quả</h2>
            <div class="absolute inset-0 bg-white opacity-10 rounded-lg pointer-events-none"></div>
          </div>
        </div>
      </div>
    </div>

    <div class="bg-white md:p-10 p-3 w-full text-center">
      <div class="bg-white rounded-2xl p-10 shadow-lg w-full mx-auto text-center border border-gray-200 relative" style="background-image: url('images/banner_login.jpg'); background-size: cover; background-position: center;">
        <div class="container mx-auto px-4">
          <div class="mx-auto flex justify-center">
            <img src="images/logo.png" alt="Logo" class="w-12 mb-3">
          </div>
          <h1 class="text-3xl font-bold mb-5 text-green-700 relative z-10" style="text-shadow: 0px 0px 10px rgba(255, 255, 255, 0.8), 0px 0px 20px rgba(255, 255, 255, 0.6); -webkit-text-stroke: 1px white;">
            TÍNH NĂNG
          </h1>
          <p class="text-white text-xl text-center mb-8">Lấy người dùng làm tâm điểm phát triển sản phẩm, Emeralpha cung cấp phương pháp tư vấn đầu tư tối ưu trong một ứng dụng duy nhất!</p>
          <div class="w-full mx-auto grid lg:grid-cols-5 md:grid-cols-3 grid-cols-1 gap-4">
            <div class="p-4 border border-green-500 rounded-lg shadow-lg shadow-green-500 hover:bg-green-100 hover:scale-105 transition-all duration-300 text-center bg-white">
              <h3 class="text-lg font-semibold mb-2 text-gray-800">Xác định xu hướng và chiến lược thị trường</h3>
            </div>
            <div class="p-4 border border-green-500 rounded-lg shadow-lg shadow-green-500 hover:bg-green-100 hover:scale-105 transition-all duration-300 text-center bg-white flex justify-center items-center">
              <h3 class="text-lg font-semibold mb-2 text-gray-800">Đo lường tâm lý thị trường</h3>
            </div>
            <div class="p-4 border border-green-500 rounded-lg shadow-lg shadow-green-500 hover:bg-green-100 hover:scale-105 transition-all duration-300 text-center bg-white flex justify-center items-center  ">
              <h3 class="text-lg font-semibold mb-2 text-gray-800">Đo lường sức mạnh thị trường</h3>
            </div>
            <div class="p-4 border border-green-500 rounded-lg shadow-lg shadow-green-500 hover:bg-green-100 hover:scale-105 transition-all duration-300 text-center bg-white lg:ms-0 lg:w-auto md:ms-[100px] md:w-[180px]">
              <h3 class="text-lg font-semibold mb-2 text-gray-800">Đánh giá cơ bản và xếp hạng cổ phiếu</h3>
            </div>
            <div class="p-4 border border-green-500 rounded-lg shadow-lg shadow-green-500 hover:bg-green-100 hover:scale-105 transition-all duration-300 text-center bg-white lg:ms-0 lg:w-auto md:ms-[100px] md:w-[180px]">
              <h3 class="text-lg font-semibold mb-2 text-gray-800">Danh mục khuyến nghị cho NDT</h3>
            </div>
          </div>


          <div class="flex items-center mt-10">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6 text-green-500">
              <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p class="ml-2 text-white">Emeralpha sử dụng công nghệ trí tuệ nhân tạo để phân tích và xử lý dữ liệu, tổng hợp thông tin dữ liệu khách quan thành hệ thống quản trị danh mục đầu tư tối ưu nhất.</p>
          </div>
        </div>

        <div class="w-full mx-auto pt-[40px] container">
          <h1 class="text-3xl font-bold mb-5 text-green-700 relative z-10" style="text-shadow: 0px 0px 10px rgba(255, 255, 255, 0.8), 0px 0px 20px rgba(255, 255, 255, 0.6); -webkit-text-stroke: 1px white;">
            QUY TRÌNH CÔNG NGHỆ
          </h1>
          <div class="relative flex flex-wrap justify-between items-start gap-4 md:gap-16">
            <div class="relative group flex-1 flex-col lg:flex-row mb-10">
              <div class="absolute left-1/2 top-6 transform translate-y-(-1/2) w-[calc(100%+2rem)] border-dashed border-green-400 border-4 z-0"></div>
              <div class="w-12 h-12 rounded-full bg-green-700 flex items-center justify-center text-white font-bold shadow-lg group-hover:bg-green-600 transition duration-300 mx-auto relative z-10">
                1
              </div>
              <div class="mt-4 p-6 bg-white rounded-lg shadow-lg shadow-green-500 transition-all duration-300 group-hover:shadow-2xl group-hover:bg-green-50 text-center md:h-[112px] flex flex-col justify-center items-center">
                <h3 class="text-xl font-semibold mb-2 text-gray-800 group-hover:text-green-600 transition duration-300">Data Center</h3>
              </div>
            </div>

            <div class="relative group flex-1 flex-col lg:flex-row mb-10">
              <div class="absolute left-1/2 top-6 transform translate-y-(-1/2) md:w-[calc(100%+2rem)] w-auto border-dashed border-green-400 border-4 z-0"></div>
              <div class="w-12 h-12 rounded-full bg-green-700 flex items-center justify-center text-white font-bold shadow-lg group-hover:bg-green-800 transition duration-300 mx-auto relative z-10">
                2
              </div>
              <div class="mt-4 p-6 bg-white rounded-lg shadow-lg shadow-green-500 transition-all duration-300 group-hover:shadow-2xl group-hover:bg-green-50 text-center md:h-[112px] flex flex-col justify-center items-center">
                <h3 class="text-xl font-semibold mb-2 text-gray-800 group-hover:text-green-600 transition duration-300">Data Analysis</h3>
              </div>
            </div>

            <div class="relative group flex-1 flex-col lg:flex-row mb-10">
              <div class="absolute left-1/2 top-6 transform translate-y-(-1/2) lg:w-[calc(100%+2rem)] md:w-auto w-[calc(100%+2rem)] border-dashed border-green-400 border-4 z-0"></div>
              <div class="w-12 h-12 rounded-full bg-green-700 flex items-center justify-center text-white font-bold shadow-lg group-hover:bg-green-800 transition duration-300 mx-auto relative z-10">
                3
              </div>
              <div class="mt-4 p-6 bg-white rounded-lg shadow-lg shadow-green-500 transition-all duration-300 group-hover:shadow-2xl group-hover:bg-green-50 text-center md:h-[112px] flex flex-col justify-center items-center">
                <h3 class="text-xl font-semibold mb-2 text-gray-800 group-hover:text-green-600 transition duration-300">Data Science</h3>
              </div>
            </div>

            <div class="relative group flex-1 flex-col lg:flex-row mb-10">
              <div class="absolute md:left-1/2 left-[-5%] md:top-6 top-[183px] transform md:translate-y-(-1/2) md:translate-x-0 -translate-x-1/2 md:translate-y-0 md:w-[calc(100%+2rem)] w-auto h-[calc(20%)] md:h-auto border-dashed border-green-400 border-4 z-0"></div>
              <div class="w-12 h-12 rounded-full bg-green-700 flex items-center justify-center text-white font-bold shadow-lg group-hover:bg-green-800 transition duration-300 mx-auto relative z-10">
                4
              </div>
              <div class="mt-4 p-6 bg-white rounded-lg shadow-lg shadow-green-500 transition-all duration-300 group-hover:shadow-2xl group-hover:bg-green-50 text-center flex flex-col justify-start items-center">
                <h3 class="text-xl font-semibold mb-2 text-gray-800 group-hover:text-green-600 transition duration-300">Machine Learning</h3>
              </div>
            </div>

            <div class="relative group flex-1 flex-col lg:flex-row mb-10">
              <div class="absolute left-1/2 md:top-6 top-[160px] transform md:translate-y-(-1/2) md:translate-x-0 -translate-x-1/2 md:translate-y-0 md:w-[calc(100%+2rem)] w-auto h-[calc(20%)] md:h-auto border-dashed border-green-400 border-4 z-0"></div>
              <div class="w-12 h-12 rounded-full bg-green-700 flex items-center justify-center text-white font-bold shadow-lg group-hover:bg-green-800 transition duration-300 mx-auto relative z-10">
                5
              </div>
              <div class="mt-4 p-6 bg-white rounded-lg shadow-lg shadow-green-500 transition-all duration-300 group-hover:shadow-2xl group-hover:bg-green-50 text-center flex flex-col justify-start items-center">
                <h3 class="text-xl font-semibold mb-2 text-gray-800 group-hover:text-green-600 transition duration-300">Stream Processing</h3>
              </div>
            </div>

            <div class="relative group flex-1 flex-col lg:flex-row mb-10">
              <div class="w-12 h-12 rounded-full bg-green-700 flex items-center justify-center text-white font-bold shadow-lg group-hover:bg-green-800 transition duration-300 mx-auto relative z-10">
                6
              </div>
              <div class="mt-4 p-6 bg-white rounded-lg shadow-lg shadow-green-500 transition-all duration-300 group-hover:shadow-2xl group-hover:bg-green-50 text-center flex flex-col justify-start items-center">
                <h3 class="text-xl font-semibold mb-2 text-gray-800 group-hover:text-green-600 transition duration-300">Business Intelligence</h3>
              </div>
            </div>
          </div>
        </div>

        <div class="w-full mx-auto flex justify-between items-center container gap-0 md:pt-[40px] flex-wrap">
          <div class="relative bg-gradient-to-r from-green-300 to-green-500 md:rounded-l-lg rounded-t-lg shadow-lg text-center text-white flex-1 min-w-[200px] md:h-48 h-24 flex justify-center items-center">
            <h3 class="text-lg font-semibold">Tích hợp dữ liệu và công cụ đầu tư chuyên sâu</h3>
            <div class="absolute right-0 top-0 h-full w-6 bg-gradient-to-r from-transparent to-white transform translate-x-1/2 md:block hidden arrow-right"></div>
          </div>
          <div class="relative bg-gradient-to-r from-green-400 to-green-600 shadow-lg text-center text-white flex-1 min-w-[200px] md:h-48 h-24 flex justify-center items-center">
            <h3 class="text-lg font-semibold">Thuật toán ứng dụng và tổng hợp dữ liệu câp nhật</h3>
            <div class="absolute right-0 top-0 h-full w-6 bg-gradient-to-r from-transparent to-white transform translate-x-1/2 md:block hidden arrow-right"></div>
          </div>
          <div class="relative bg-gradient-to-r from-green-500 to-green-700 shadow-lg text-center text-white flex-1 min-w-[200px] md:h-48 h-24 flex justify-center items-center">
            <h3 class="text-lg font-semibold">Phương pháp đầu tư từ các nhà quản lý đầu tư quỹ kinh nghiệm</h3>
            <div class="absolute right-0 top-0 h-full w-6 bg-gradient-to-r from-transparent to-white transform translate-x-1/2 arrow-right lg:block hidden"></div>
          </div>
          <div class="relative bg-gradient-to-r from-green-600 to-green-800 shadow-lg text-center text-white flex-1 min-w-[200px] md:h-48 h-24 flex justify-center items-center">
            <h3 class="text-lg font-semibold">Kết quả khuyến nghị tự động và hiệu quả</h3>
            <div class="absolute right-0 top-0 h-full w-6 bg-gradient-to-r from-transparent to-white transform translate-x-1/2 md:block hidden arrow-right"></div>
          </div>
          <div class="relative bg-gradient-to-r from-green-700 to-green-900 md:rounded-r-lg rounded-b-lg shadow-lg text-center text-white flex-1 min-w-[200px] md:h-48 h-24 flex justify-center items-center">
            <h3 class="text-lg font-semibold">Tư duy quản lý và hỗ trợ thực chiến cho NDT</h3>
          </div>
        </div>
      </div>
    </div>

    <div class="bg-white md:p-10 p-3 w-full text-center">
      <div class="bg-white rounded-2xl p-10 shadow-lg w-full mx-auto text-center border border-gray-200 relative" style="background-image: url('images/bogau.jpg'); background-size: cover; background-position: center;">
        <h1 class="md:text-3xl text-xl font-bold mb-5 text-yellow-700 relative z-10" style="text-shadow: 0px 0px 10px rgba(255, 255, 255, 0.8), 0px 0px 20px rgba(255, 255, 255, 0.6); -webkit-text-stroke: 1px white;">
          Tham gia cùng cộng đồng nhà đầu tư và chuyên gia tài chính của chúng tôi
        </h1>
        <div class="grid md:grid-cols-2 grid-cols-1 gap-4">
          <div class="relative overflow-hidden rounded-lg">
            <img src="images/nguyetque.png" alt="Image 1" class="lg:w-96 w-80 h-80 lg:h-96 w-80 h-80 object-cover ml-auto" />
            <div class="absolute lg:top-[118px] lg:right-[88px] md:top-[95px] md:right-[50px] top-[82px] right-[56px] flex items-center justify-center text-yellow-500 text-xl font-bold" style="text-shadow: 1px 1px 0px black, -1px -1px 0px black, 1px -1px 0px black, -1px 1px 0px black;">
              Đem đến hiệu quả <br> tối đa trong quản lý <br> đầu tư
            </div>
          </div>

          <div class="overflow-hidden rounded-lg relative">
            <img src="images/nguyetque.png" alt="Image 2" class="lg:w-96 w-80 h-80 lg:h-96 w-80 h-80 object-cover" />
            <div class="absolute lg:top-[114px] lg:left-[95px] md:top-[95px] md:left-[43px] top-[80px] left-[48px] flex items-center justify-center text-yellow-500 text-xl font-bold" style="text-shadow: 1px 1px 0px black, -1px -1px 0px black, 1px -1px 0px black, -1px 1px 0px black;">
              Được các <br> chuyên gia tài chính <br> khuyên dùng
            </div>
          </div>
          <div class="overflow-hidden rounded-lg relative">
            <img src="images/nguyetque.png" alt="Image 3" class="lg:w-96 w-80 h-80 lg:h-96 w-80 h-80 object-cover ml-auto" />
            <div class="absolute lg:top-[110px] lg:right-[92px] md:top-[110px] md:right-[57px] top-[101px] right-[67px] flex items-center justify-center text-yellow-500 text-xl font-bold" style="text-shadow: 1px 1px 0px black, -1px -1px 0px black, 1px -1px 0px black, -1px 1px 0px black;">
              Tích hợp trên <br> ứng dụng di động
            </div>
          </div>
          <div class="overflow-hidden rounded-lg relative">
            <img src="images/nguyetque.png" alt="Image 4" class="lg:w-96 w-80 h-80 lg:h-96 w-80 h-80 object-cover" />
            <div class="absolute lg:top-[114px] lg:left-[115px] md:top-[114px] md:left-[72px] top-[100px] left-[79px] flex items-center justify-center text-yellow-500 text-xl font-bold" style="text-shadow: 1px 1px 0px black, -1px -1px 0px black, 1px -1px 0px black, -1px 1px 0px black;">
              Kết nối trực tiếp <br> với hệ thống
            </div>
          </div>
        </div>

        <div class="mt-5 flex md:flex-row flex-col justify-center gap-4">
          <a
            href="https://forms.office.com/Pages/ResponsePage.aspx?id=DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAN__gqid45UODZTVEdVWkhSRzNNNlpFQ1JGM0pNQ1BHNC4u"
            target="_blank"
            class="bg-white text-black py-4 px-10 rounded-lg shadow-lg shadow-green-500 transition duration-300 md:w-96 w-80 text-center hover:bg-green-700 hover:text-white hover:shadow-xl hover:shadow-green-600 transform hover:scale-110">
            Đăng ký trải nghiệm sử dụng
          </a>
          <a
            href="https://zalo.me/g/dmpeco615"
            target="_blank"
            class="bg-white text-black py-4 px-10 rounded-lg shadow-lg shadow-green-500 transition duration-300 md:w-96 w-80 text-center hover:bg-green-700 hover:text-white hover:shadow-xl hover:shadow-green-600 transform hover:scale-110">
            Tham gia ngay
          </a>
        </div>

        <div class="container mx-auto md:mt-[80px] mt-[40px]">
          <h1 class="text-3xl font-bold mb-5 text-white relative z-10" style="text-shadow: 1px 1px 0px black, -1px -1px 0px black, 1px -1px 0px black, -1px 1px 0px black;">
            GIÁ TRỊ ĐEM LẠI CHO NHÀ ĐẦU TƯ ĐỒNG HÀNH
          </h1>
          <div class="flex flex-col justify-center items-center gap-2">
            <div class="flex flex-col w-full max-w-[800px] items-center bg-white rounded-lg shadow-md mb-4">
              <div class="p-2">
                <img src="images/tem.png" alt="Icon 1" class="w-10 h-10" />
              </div>
              <div class="bg-green-700 p-5 w-full rounded-b-lg">
                <p class="font-bold text-white">Kiểm soát hoàn toàn yếu tố cảm xúc</p>
              </div>
            </div>

            <div class="flex flex-col w-full max-w-[800px] items-center bg-white rounded-lg shadow-md mb-4">
              <div class="p-2">
                <img src="images/hieuqua.png" alt="Icon 2" class="w-10 h-10" />
              </div>
              <div class="bg-green-700 p-5 w-full rounded-b-lg">
                <p class="font-bold text-white">Tối đa hóa hiệu quả đầu tư</p>
              </div>
            </div>

            <div class="flex flex-col w-full max-w-[800px] items-center bg-white rounded-lg shadow-md mb-4">
              <div class="p-2">
                <img src="images/heo.png" alt="Icon 3" class="w-10 h-10" />
              </div>
              <div class="bg-green-700 p-5 w-full rounded-b-lg">
                <p class="font-bold text-white">Tối ưu thời gian, công sức trong đầu tư</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <div class="bg-gray-900 text-white mt-5 px-4 sm:px-8 lg:px-10 py-5 pb-[100px]">
      <header class="pt-4 ms-5">
        <button class="bg-[rgb(7,130,44)] hover:bg-[rgb(5,110,40)] text-white font-bold py-2 px-4 sm:py-3 sm:px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 ease-in-out">
          Đăng ký <span class="text-lg font-extrabold text-yellow-400 ms-1">Emeralpha AI Copytrade</span>
        </button>
      </header>

      <div class="mt-5">
        <h1 class="text-2xl sm:text-3xl md:text-4xl font-bold text-[rgb(7,130,44)] my-10 ms-5">Cá Nhân Hóa Theo Phong Cách Đầu Tư</h1>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div class="flex flex-col col-span-1 lg:col-span-5 lg:gap-40 gap-0 ms-5">
            <ul class="list-disc pl-5 space-y-2">
              <li class="text-base sm:text-lg">Tận dụng ưu thế vượt trội từ Emeralpha AI Trading: đầu tư chứng khoán & quản trị danh mục đầu tư tự động trên chính tài khoản của NDT tại công ty chứng khoán hợp tác với Emeralpha Capital Management.</li>
              <li class="text-base sm:text-lg">Emeralpha AI Copytrade là sản phẩm quản lý đầu tư nhằm cá nhân hóa nhu cầu, phong cách đầu tư của nhà đầu tư theo tư duy quản trị của giám đốc quỹ đầu tư.</li>
            </ul>
            <div class="mt-10 mx-auto">
              <img src="images/logo.png" alt="Logo" class="w-32 sm:w-48 lg:w-64">
            </div>
          </div>
          <img src="images/robotAI.jpg" alt="traders" class="col-span-1 lg:col-span-7 mx-auto rounded-lg mb-6 w-full h-auto object-cover">
        </div>
      </div>

      <div class="flex flex-wrap justify-center gap-16 py-8 bg-gray-700">
        <div class="bg-gray-800 lg:p-4 p-3 rounded-lg w-64 lg:w-72 text-center text-sm lg:h-48 h-[10rem] flex flex-col justify-center items-center">
          <h3 class="text-lg sm:text-xl lg:text-xl font-semibold text-[rgb(7,130,44)] mb-2">Linh hoạt phương thức đầu tư</h3>
          <p>Dễ dàng điều chỉnh danh mục đầu tư của bạn để phù hợp với chiến lược và nhu cầu tài chính cá nhân.</p>
        </div>
        <div class="bg-gray-800 lg:p-6 p-4 rounded-lg w-64 lg:w-72 text-center text-sm lg:h-48 h-[10rem] flex flex-col justify-center items-center">
          <h3 class="text-lg sm:text-xl lg:text-xl font-semibold text-[rgb(7,130,44)] mb-2">Bảo mật thông tin, Minh bạch thành quả</h3>
          <p>Thông tin đầu tư của bạn luôn được bảo vệ, kết quả rõ ràng và minh bạch.</p>
        </div>
        <div class="bg-gray-800 lg:p-6 p-4 rounded-lg w-64 lg:w-72 text-center text-sm lg:h-48 h-[10rem] flex flex-col justify-center items-center">
          <h3 class="text-lg sm:text-xl lg:text-xl font-semibold text-[rgb(7,130,44)] mb-2">Linh hoạt vốn và thời gian đầu tư</h3>
          <p>Tối ưu hóa lợi nhuận với chiến lược đầu tư linh hoạt và hiệu quả.</p>
        </div>
        <div class="bg-gray-800 lg:p-6 p-4 rounded-lg w-64 lg:w-72 text-center text-sm lg:h-48 h-[10rem] flex flex-col justify-center items-center">
          <h3 class="text-lg sm:text-xl lg:text-xl font-semibold text-[rgb(7,130,44)] mb-2">Quản trị khẩu vị rủi ro</h3>
          <p>Kiểm soát rủi ro đầu tư theo mức độ phù hợp với khẩu vị của bạn.</p>
        </div>
      </div>
    </div>

    <?php $options = $settings['options']; ?>
    <footer class="lg:pl-[320px] p-8 py-2 bg-zinc-900	lg:fixed bottom-0 w-full text-white overflow-auto">
      <div class="flex flex-col lg:flex-row gap-4 justify-start items-center text-grey text-sm">
        <div class="w-full lg:w-4/12">
          <div class="flex gap-4 flex-row align-center items-center">
            <img class="w-16" src="<?php echo url('images/logo.png'); ?>">
            <div class="text-lg text-primary">
              <h1>Emeralpha Capital</h1>
              <h1>Management</h1>
            </div>
          </div>
        </div>
        <div class="w-full lg:w-4/12">
          <?php if (isset($options['website'])) { ?>
            <div>Website: <a href="http://<?php echo $options['website']['url']; ?>" class="text-white hover:text-primary" target="_blank"><?php echo $options['website']['url']; ?></a></div>
          <?php } ?>
          <?php if (isset($options['email'])) { ?>
            <div>Email: <a href="mailto:<?php echo $options['email']['url']; ?>" class="text-white hover:text-primary" target="_blank"><?php echo $options['email']['url']; ?></a></div>
          <?php } ?>
          <div>Phone:
            <?php if (isset($options['phone1']) && $options['phone1']['url'] != '') { ?>
              <a class="text-white hover:text-primary" href="tel:<?php echo $options['phone1']['url']; ?>" target="_blank"><?php echo $options['phone1']['url']; ?></a>
            <?php } ?>
            <?php if (isset($options['phone2']) && $options['phone2']['url'] != '') { ?>
              -
              <a class="text-white hover:text-primary" href="tel:<?php echo $options['phone2']['url']; ?>" target="_blank"><?php echo $options['phone2']['url']; ?></a>
            <?php } ?>
          </div>
        </div>
        <div class="w-full lg:w-4/12">
          <?php if (isset($options['socials'])) { ?>
            <div class="flex gap-5 lg:justify-end mb-3">
              <?php foreach ($options['socials'] as $i => $item) { ?>
                <a target="_blank" href="<?php echo nl2br(e($item['url'])); ?>">
                  <img class="w-12 h-12 object-contain" src="<?php echo e(Storage::url($item['image'])); ?>">
                </a>
              <?php } ?>
            </div>
          <?php } ?>
          <?php if (isset($options['copyright'])) { ?>
            <div class="flex lg:justify-end text-xs"><?php echo $options['copyright']['url']; ?></div>
          <?php } ?>
        </div>
      </div>
    </footer>
  </div>
</body>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.3/jquery-ui.js"></script>
<script src="https://pagination.js.org/dist/2.6.0/pagination.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.js"></script>
<script>
  $('#login-form').on("submit", function() {
    console.log('aaa');
    $(this).find("button[type='submit']").prop('disabled', true);
  });
</script>

</html><?php /**PATH /var/www/html/resources/views/layouts/auth-master.blade.php ENDPATH**/ ?>